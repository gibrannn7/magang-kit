<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config = [
    'protocol'    => 'smtp',
    'smtp_host'   => 'smtp-relay.brevo.com',
    'smtp_port'   => 587,
    'smtp_user'   => '9e60cd001@smtp-brevo.com',
    'smtp_pass'   => 'HhrAdMbyzPw6CQsp',
    'smtp_crypto' => 'tls',
    'mailtype'    => 'html',
    'charset'     => 'utf-8',
    'newline'     => "\r\n",
    'wordwrap'    => TRUE,
    'crlf'        => "\r\n"
];

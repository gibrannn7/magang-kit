<!-- <nav class="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex items-center">
                <a href="<?= base_url() ?>" class="flex-shrink-0 flex items-center gap-2">
                    <img class="h-8 w-auto" src="<?= base_url('assets/img/logo.png') ?>" alt="BPS Banten">
                    <span class="font-bold text-lg text-blue-900">Magang BPS Banten</span>
                </a>
            </div>
            <div class="flex items-center space-x-4">
                <a href="<?= base_url() ?>" class="text-gray-600 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Home</a>
                <a href="<?= base_url('auth/login') ?>" class="text-gray-600 hover:text-blue-600 px-3 py-2 rounded-md text-sm font-medium">Login Peserta/Admin</a>
                <a href="<?= base_url('daftar') ?>" class="bg-blue-600 text-white hover:bg-blue-700 px-4 py-2 rounded-md text-sm font-medium transition">Daftar Magang</a>
            </div>
        </div>
    </div>
</nav>
<main class="min-h-screen"> -->
